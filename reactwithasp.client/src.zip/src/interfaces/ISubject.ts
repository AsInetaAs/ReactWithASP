export interface ISubject {
    id: number;
    title: string;
    credits: number; 
}