export interface IStudyProgramme {
    id: number;
    title: string;
    description: string;
    duration: number; // Duration in years
}