﻿import { useEffect, useState } from "react";
import { getApi, postApi, deleteApi } from "../../api";
import { IStudyProgramme } from "../../interfaces/IStudyProgramme";
import { ISubject } from "../../interfaces/ISubject";
import { Modal } from "../components/Modal";
import { SubjectInfo } from "./components/SubjectInfo";

export default function ProgrammeSubjects() {
    const [programmes, setProgrammes] = useState<IStudyProgramme[]>([]);
    const [subjects, setSubjects] = useState<ISubject[]>([]);
    const [programmeId, setProgrammeId] = useState<number | undefined>();
    const [subjectId, setSubjectId] = useState<number | undefined>();
    const [visibleModal, setVisibleModal] = useState(false);

    useEffect(() => {
        (async () => {
            const ps = await getApi<IStudyProgramme[]>("programmes");
            if (ps) setProgrammes(ps);
            const ss = await getApi<ISubject[]>("subjects");
            if (ss) setSubjects(ss);
        })();
    }, []);

    const selectedSubject = subjects.find(s => s.id === subjectId);

    return (
        <div>
            <div className="text-3xl">Programme subjects</div>
            <div>
                <label>Pasirinkite studijų programą</label>
                <select value={programmeId ?? ""} onChange={e => setProgrammeId(e.target.value ? parseInt(e.target.value, 10) : undefined)}
                >
                    <option value="">-- select --</option> {programmes.map(p => ( <option key={p.id} value={p.id}>{p.title}</option>
                    ))}
                </select>
            </div>

            <div>
                <label>Pasirinkite studijų dalyką</label>
                <select value={subjectId ?? ""} onChange={e => setSubjectId(e.target.value ? parseInt(e.target.value, 10) : undefined)}
                >
                    <option value="">-- select --</option> {subjects.map(s => ( <option key={s.id} value={s.id}>{s.title}</option>
                    ))}
                </select>
            </div>

            <div>
                <button type="button"  onClick={() => programmeId && subjectId && postApi(`programmes/${programmeId}/subjects/${subjectId}`, {})
                    }
                >
                    Pridėti
                </button>

                <button type="button"  onClick={() =>  programmeId && subjectId &&  deleteApi(`programmes/${programmeId}/subjects/${subjectId}`, {})
                    }
                >
                    Šalinti
                </button>

                <button type="button" onClick={() => setVisibleModal(true)} disabled={!selectedSubject}
                >
                    Peržiūrėti dalyko informaciją
                </button>
            </div>

            {visibleModal ? (
                <Modal visibleModal={visibleModal} setVisibleModal={setVisibleModal} title="Subject info"
                >
                    <SubjectInfo subject={selectedSubject!} />
                    
                </Modal>
            ) : null}   
        </div>
    );
}
